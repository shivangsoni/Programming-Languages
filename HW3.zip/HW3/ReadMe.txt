Name: Shivang Soni
Student ID: 915623718
CSIF username: ssoni
Email-ID: ssoni@ucdavis.edu

All the parts of working 


Program Hierarchy:

Part 1:
Element.java: Impelementation for abstract class Element
MyChar.java: Implementation for Class MyChar which inherits from class 
Element 
MyInteger.java:Implementation for Class MyInteger which inherits from
class  Element 
Sequence.java: Implementation for Class Sequence which inherits from
class  Element 


Part 2:
Element.java: Impelementation for abstract class Element
MyChar.java: Implementation for Class MyChar which inherits from class 
Element 
MyInteger.java:Implementation for Class MyInteger which inherits from
class  Element 
Sequence.java: Implementation for Class Sequence which inherits from
class  Element 

Part 3:
Element.java: Impelementation for abstract class Element
MyChar.java: Implementation for Class MyChar which inherits from class 
Element 
MyInteger.java:Implementation for Class MyInteger which inherits from
class  Element 
Sequence.java: Implementation for Class Sequence which inherits from
class  Element 

Part 4:
Element.java: Impelementation for abstract class Element
MyChar.java: Implementation for Class MyChar which inherits from class 
Element 
MyInteger.java:Implementation for Class MyInteger which inherits from
class  Element 
Sequence.java: Implementation for Class Sequence which inherits from
class  Element 
SequenceIterator.java:Implementation for Class SequenceIterator which
does not inherits from any class it is an iterator for sequence class

Part 5:
Element.java: Impelementation for abstract class Element
MyChar.java: Implementation for Class MyChar which inherits from class 
Element 
MyInteger.java:Implementation for Class MyInteger which inherits from
class  Element 
Sequence.java: Implementation for Class Sequence which inherits from
class  Element 
SequenceIterator.java:Implementation for Class SequenceIterator which
does not inherits from any class it is an iterator for sequence class
Matrix.java: Implementation for Class Sequence which inherits from
class  Sequence


Part 6:
Element.java: Impelementation for abstract class Element
MyChar.java: Implementation for Class MyChar which inherits from class 
Element 
MyInteger.java:Implementation for Class MyInteger which inherits from
class  Element 
Sequence.java: Implementation for Class Sequence which inherits from
class  Element 
SequenceIterator.java:Implementation for Class SequenceIterator which
does not inherits from any class it is an iterator for sequence class
Matrix.java: Implementation for Class Sequence which inherits from
class  Sequence
Pair.java: Include implementation of key value pair.This inherits 
from class Element
Map.java:Implementation of class Map which inherits from class Pair
Mapiterator.java:Implementation of class Mapiterator.This iterates over 
key value pair.This inherits from class Pair