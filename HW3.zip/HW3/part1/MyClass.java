import java.io.*;
class MyClass
{
    public static void main(String args[])
    {
      System.out.println("Test");
    }
}