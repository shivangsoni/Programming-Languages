//abstract class element from which other class inherits.
abstract class Element
{
 
}