Name: Shivang Soni
Student ID: 915623718
CSIF username: ssoni
Email-ID: ssoni@ucdavis.edu

All the parts of working.

All the output are same except from some of the output ordering.

In puzzle output :
Sail none to left //Means farmer alone sails without 
                   taking anything alonge.
                   

